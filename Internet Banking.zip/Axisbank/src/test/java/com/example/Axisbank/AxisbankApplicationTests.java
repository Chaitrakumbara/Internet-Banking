package com.example.Axisbank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AxisbankApplicationTests {

	@Test
	void contextLoads() {
	}

}
